class Stack{
    constructor(){
        this.items =[]
    }

    push(element){
        this.items.push(element)
    }

    pop(){
        if(this.items.length == 0){
            return "Underflow: stack is empty, cant pop"
        }
        return this.items.pop()
    }

    peek(){
        return this.items[this.items.length-1];
    }
    
    isEmpty(){
        return this.items.length == 0;
    }


    showStack(){
        if(this.items.length==0){
            return "stack is empty"
        }
        let str = "";
        for (let index = 0; index < this.items.length; index++) {
            str+=this.items[index] + " ";
        }
        return str;
    }
}


function reverse(value){
    let st = new Stack();
    for (let index = 0; index < value.length; index++) {
        st.push(value[index])
    }
    let result ="";
    while(!st.isEmpty()){
        result+=st.pop()
    }
    return result
    }
    
    let s = "ashish";
    console.log(reverse(s))

// let stack = new Stack();
// console.log(stack.isEmpty())
// console.log(stack.pop())
// stack.push(10);
// stack.push(20);
// stack.push(30)
// console.log(stack.showStack())
// stack.pop()
// console.log(stack.showStack())
// stack.pop()
// console.log(stack.showStack())
// console.log(stack.isEmpty())
// stack.pop()
// console.log(stack.showStack())
// console.log(stack.isEmpty());