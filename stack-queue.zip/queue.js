class Queue{
    constructor(){
        this.items =[];
        this.front=0;
        this.rear=0;
    }

    isEmpty(){
        if(this.front== this.rear){
            return true;
        } else{
            return false;
        }
    }

    enqueue(value){
        this.items[this.rear] = value;
        this.rear++;
        return value+" inserted"
    }

    dequeue(){
        if(this.front==this.rear){
            return "empty"
        }
        let item = this.items[this.front];
        delete this.items[this.front]
        this.front++;
        return item;
    }

    peek(){
        return this.items[this.front]
    }

    showQueue(){
        return this.items;
    }
}

let q = new Queue();
console.log(q.enqueue(10))
console.log(q.enqueue(20))
console.log(q.enqueue(30))
console.log(q.enqueue(40))
console.log(q.enqueue(50))
console.log(q.showQueue())

console.log(q.dequeue())
console.log(q.dequeue())

console.log(q.showQueue())

console.log(q.isEmpty())