package com.ashish;

import java.util.PriorityQueue;
import java.util.Scanner;

public class MilkShake {
    public static void main(String[] args) {
        int[] arr = new int[3];
        Scanner sc = new Scanner(System.in);
        System.out.println("Total number of orders for Mango milkshake");
        arr[0] = sc.nextInt();

        System.out.println("Total number of orders for Orange milkshake");
        arr[1] = sc.nextInt();

        System.out.println("Total number of orders for Pineapple milkshake");
        arr[2] = sc.nextInt();

        System.out.println(timeToMakeJuice(arr));
    }

    public static int timeToMakeJuice(int[] order){
        int time = 0;
        PriorityQueue<Integer> pq = new PriorityQueue<>((o1, o2) -> o2-o1);
        for (int i:order){
            pq.add(i);
        }
        while (pq.size()>1){
            time++;
            int first = pq.remove()-1;
            int second = pq.remove()-1;
            if (first>0){
                pq.add(first);
            }
            if (second>0){
                pq.add(second);
            }
        }
        if (pq.size()==1){
            time+=pq.remove();
        }
        return time;
    }
}
