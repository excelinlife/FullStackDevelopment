package com.ashish;

public class LinkedList {
    Nod head;

    public static void main(String[] args) {
        LinkedList list =new LinkedList();
        list.head = new Nod(1);
        Nod second = new Nod(2);
        Nod third = new Nod(3);
        Nod fourth = new Nod(4);
        list.head.next= second;
        second.next=third;
        third.next=fourth;
        fourth.next=null;
        print(list.head);
        print(reverse(list.head));
    }

    public static Nod reverse(Nod head){
        Nod cur = head;
        Nod prev = null;
        Nod next;
        while (cur!=null){
            next = cur.next;
            cur.next = prev;
            prev = cur;
            cur =next;
        }
        Nod h = prev;
        return h;
    }

    public static void print(Nod head){
        while (head!=null){
            System.out.print(head.data+ " -> ");
            head=head.next;
        }
        System.out.println();
    }
}
class Nod{
    int data;
    Nod next;

    public Nod(int data) {
        this.data = data;
        this.next=null;
    }
}
