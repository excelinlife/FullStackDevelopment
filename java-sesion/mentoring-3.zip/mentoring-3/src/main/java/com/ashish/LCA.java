package com.ashish;
class Node {
    int data;
    Node left, right;

    Node(int value) {
        data = value;
        left = right = null;
    }
}

class Tree{
    Node root;

    public Tree(Node root) {
        this.root = root;
    }

    public static void main(String[] args) {
        Node root = new Node(10);
        Tree binaryTree = new Tree(root);
        binaryTree.root.left = new Node(20);
        binaryTree.root.right = new Node(30);
        root.left.left=new Node(40);
        root.left.right=new Node(50);
        root.right.left=new Node(60);
        root.right.right=new Node(70);
        System.out.println(lCA(root,20,30).data);
    }

    public static Node lCA(Node root, int n1, int n2){
        if (root==null){
            return null;
        }
        if (root.data==n1 || root.data== n2){
            return root;
        }
        Node left = lCA(root.left, n1, n2);
        Node right = lCA(root.right, n1, n2);
        if (left!=null && right!=null){
            return root;
        }
        return ((left!=null)?left:right);
    }
}